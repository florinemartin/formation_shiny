#' @import glue
#' @export

dire_bonjour <- function(prenom = "toi"){
  glue("Bonjour {prenom} !")
}
